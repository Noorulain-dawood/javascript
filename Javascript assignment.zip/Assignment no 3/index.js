alert("Assignment no 3 started!")
var age ="21";
alert("My age is " + age);



var birthYear="1998";
document.write("My birth year is " + birthYear +"<br>" + "Data type of my declare varaible is number");
