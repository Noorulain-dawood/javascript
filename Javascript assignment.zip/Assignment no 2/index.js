var username ="Ali";
var myname ="Noorulain";
var fullname =username+myname;
document.write('Task no 1 and 2'+ fullname);
// var repeat = "Pizza";
// // var i=repeat;
// for(var i=5; i>=0 ; i--)
// {
//   for(var j=5; j<=i ;j--)
//   {
//       document.write(repeat[i]);
//       console.log(repeat[i]);
//   }
//      document.write('\n');
// }
var email ="unoor5175@gmail.com";
alert("Task no 6 My email address is " + email);
var book = "A smarter way to learn javascript";
alert("Task no 7 I am trying to learn from the book " + book);
