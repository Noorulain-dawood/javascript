alert("Assignment no 4 Started ..")
var $my_Class , $class , _mainClass;
var number2, $sign , _first ,myName ,your_name;
// var 4four ,@gmail , for ,&book *hello;  inlegal variables
document.write("Rules for naming JS variables" + "<br>" +
"  b)  Variable names can only contain  number, $ and _ For example $my_1stVariable " + "<br>" +
"c) Variables must begin with a letter, $ or _. For example $name, _name or name" + "<br>" +
"d)  Variable names are case sensitive " + "<br>" +
"e) Variable names should not be JS Keywords."
 );
