alert("Hello! welcome here");
alert("Error! please enter a valid password");
alert("Welcome to JS land \n Happy Coding.." );
alert("Welcome to js land ");
// alert("Happy coding \n "  <input type="checkbox" > "Prevent this page from addtional dialogs");
// alert("Hello! I can run through my web browser console.");
